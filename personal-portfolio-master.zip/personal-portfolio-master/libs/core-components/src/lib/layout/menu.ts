export const menu = [
  {
    label: 'Landing',
    path: '/',
  },
  {
    label: 'Bio',
    path: '/bio',
  },
  {
    label: 'Portfolio',
    path: '/portfolio',
  },
  {
    label: 'Blog',
    path: '/posts',
  },
  {
    label: 'Contact',
    path: '/contact',
  },
];
